self.__precacheManifest = [
  {
    "revision": "7c4f45329e47798217a3",
    "url": "/admin/static/js/runtime~main.b3695f6e.js"
  },
  {
    "revision": "ac4a1cd31a9eb5dea556",
    "url": "/admin/static/js/main.8eee9a34.chunk.js"
  },
  {
    "revision": "e2ec3d9ce8995dcc73e5",
    "url": "/admin/static/js/2.d842664d.chunk.js"
  },
  {
    "revision": "ac4a1cd31a9eb5dea556",
    "url": "/admin/static/css/main.ef36aea8.chunk.css"
  },
  {
    "revision": "e2ec3d9ce8995dcc73e5",
    "url": "/admin/static/css/2.7375eb1f.chunk.css"
  },
  {
    "revision": "1fed318b7c4f7ab7e6a85c693885d68d",
    "url": "/admin/index.html"
  }
];